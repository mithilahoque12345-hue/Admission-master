# Admission Master — Android Studio project

This is an initial offline Android app project. It contains a WebView-based interface and a small sample MCQ set.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- This is a starter build, not a complete admission question bank.
- The included MCQs are illustrative sample questions, not verified past-paper questions.
- Exam history is stored locally in the app's WebView storage.
- The project needs Android Studio/Android SDK to compile and produce an installable APK.
